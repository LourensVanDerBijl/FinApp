using FinBineBackend.AdminDatabaseView.Logs.Models;
using FinBineBackend.LoggingLogic.LogDbWrite.Models;
using FinBineBackend.LoggingLogic.LogDbWrite.Services;

namespace FinBineBackend.AdminDatabaseView.Logs.Services
{
    // Quiet by design, same convention as the other logging services —
    // a clean list/add/delete produces zero log entries. Only auth
    // failures, manual writes/deletes that touch real data, and
    // partial failures are worth a record.
    public class AdminDatabaseViewLoggingService
    {
        public void LogUnauthorizedAccess(string ipAddress) =>
            CreateLog("Warning", "Auth", $"Non-admin or invalid token tried to reach the Database View page (IP: {ipAddress})");

        // A manual test-data row was created — worth a trail since,
        // unlike self-service registration, this is a human directly
        // writing rows into all 3 stores.
        public void LogManualUserAdded(string userId, string email) =>
            CreateLog("Info", "AdminDatabaseView", $"Manual user record added: {userId} ({email})");

        public void LogAddFailed(string failedAtSource, string email, string reason) =>
            CreateLog("Error", failedAtSource, $"Manual add failed for {email} at {failedAtSource}: {reason}");

        public void LogAddRollbackFailed(string source, string? userId, string? firebaseUid, string reason) =>
            CreateLog("Critical", source,
                $"ROLLBACK FAILED for manual add (userId={userId ?? "none"}, firebaseUid={firebaseUid ?? "none"}) — manual cleanup required. Reason: {reason}");

        // Deletion is best-effort per store, so partial deletes are
        // expected (an orphaned row) — logged as Info, not Warning.
        public void LogUserDeleted(string identifier, bool firebaseAuthDeleted, bool firestoreDeleted, bool postgresDeleted) =>
            CreateLog("Info", "AdminDatabaseView",
                $"User record deleted ({identifier}) — FirebaseAuth: {firebaseAuthDeleted}, Firestore: {firestoreDeleted}, Postgres: {postgresDeleted}");

        public void LogDeleteFailed(string identifier, string reason) =>
            CreateLog("Error", "AdminDatabaseView", $"Delete failed for {identifier}: {reason}");

        private void CreateLog(string level, string source, string message)
        {
            var log = new AdminDatabaseViewLog
            {
                Level = level,
                Source = source,
                Message = message
            };

            LogQueue.Enqueue(new LogDbRecord
            {
                Id = log.Id,
                Timestamp = log.Timestamp,
                Type = log.Type,
                Source = log.Source,
                Level = log.Level,
                Message = log.Message
            });
        }
    }
}
