﻿using FinBineBackend.UserGroupRegistration.Logs.Models;
using FinBineBackend.LoggingLogic.LogDbWrite.Models;
using FinBineBackend.LoggingLogic.LogDbWrite.Services;

namespace FinBineBackend.UserGroupRegistration.Logs.Services
{
    // Deliberately quiet by design, same convention as
    // UserRegistrationLoggingService/UserLoginLoggingService — a clean
    // group creation produces zero log entries. Only validation
    // rejections, rollbacks, and token problems are logged.
    public class UserGroupRegistrationLoggingService
    {
        // The token is structurally invalid — not just expired or
        // revoked, but doesn't check out at all. Worth treating as a
        // possible theft attempt, same as UserLoginLoggingService.
        public void LogTokenMismatch(string ipAddress) =>
            CreateLog("Critical", "Auth", $"Group creation token failed verification — possible account theft attempt (IP: {ipAddress})");

        // A request was rejected before anything was created — failed
        // validation (bad group name/type), no matching fb_users
        // profile, or the owner already belongs to a group.
        public void LogRegistrationRejected(string source, string userId, string reason) =>
            CreateLog("Warning", source, $"Group creation rejected for {userId}: {reason}");

        // A step failed AFTER something else had already succeeded
        // (fb_groups, fb_users, or Postgres) — this is what triggers
        // the all-or-nothing rollback across whichever of those three
        // systems already changed.
        public void LogRollbackTriggered(string source, string ownerUserId, string? groupId, string reason) =>
            CreateLog("Error", source,
                $"Group creation failed for owner {ownerUserId} (groupId: {groupId ?? "not yet assigned"}) — rolling back. Reason: {reason}");

        // Worst case: undoing an already-completed step also failed,
        // leaving an orphaned record (in Firestore or Postgres) that
        // needs manual cleanup.
        public void LogRollbackFailed(string source, string ownerUserId, string? groupId, string reason) =>
            CreateLog("Critical", source,
                $"ROLLBACK FAILED for groupId={groupId ?? "unknown"}, owner={ownerUserId} — manual cleanup required. Reason: {reason}");

        private void CreateLog(string level, string source, string message)
        {
            var log = new UserGroupRegistrationLog
            {
                Level = level,
                Source = source,
                Message = message
            };

            LogQueue.Enqueue(new LogDbRecord
            {
                Id = log.Id,
                Timestamp = log.Timestamp,
                Type = log.Type,
                Source = log.Source,
                Level = log.Level,
                Message = log.Message
            });
        }
    }
}
