using FinBineBackend.AdminTestDataImport.Logs.Models;
using FinBineBackend.LoggingLogic.LogDbWrite.Models;
using FinBineBackend.LoggingLogic.LogDbWrite.Services;

namespace FinBineBackend.AdminTestDataImport.Logs.Services
{
    // Same "quiet unless it matters" convention as AdminDatabaseViewLoggingService.
    public class AdminTestDataImportLoggingService
    {
        public void LogUnauthorizedAccess(string ipAddress) =>
            CreateLog("Warning", "Auth", $"Non-admin or invalid token tried to reach Test Data import (IP: {ipAddress})");

        public void LogValidationRejected(int errorCount, int groupCount) =>
            CreateLog("Info", "AdminTestDataImport",
                $"Import rejected at validation — {errorCount} error(s) across {groupCount} group(s). Nothing was written.");

        public void LogImportSucceeded(int groupsCreated, int usersCreated) =>
            CreateLog("Info", "AdminTestDataImport",
                $"Batch import completed — {groupsCreated} group(s), {usersCreated} user(s) written across all 3 stores.");

        public void LogImportFailed(string failedAtSource, string detail, string reason) =>
            CreateLog("Error", failedAtSource, $"Batch import failed at {failedAtSource} ({detail}): {reason}");

        public void LogClearAllCompleted(int firebaseDeleted, int firestoreDeleted, int postgresDeleted, int firestoreGroupsDeleted, int postgresGroupsDeleted, int protectedCount, int errorCount) =>
            CreateLog(errorCount > 0 ? "Warning" : "Info", "AdminTestDataImport",
                $"Clear-all-test-data completed — {firebaseDeleted} Firebase Auth, {firestoreDeleted} Firestore, " +
                $"{postgresDeleted} Postgres user row(s) deleted; {firestoreGroupsDeleted} Firestore, {postgresGroupsDeleted} " +
                $"Postgres group(s) deleted; {protectedCount} email(s) protected, {errorCount} error(s).");

        public void LogRollbackFailed(string source, string detail, string reason) =>
            CreateLog("Critical", source,
                $"ROLLBACK FAILED during batch import ({detail}) — manual cleanup required. Reason: {reason}");

        private void CreateLog(string level, string source, string message)
        {
            var log = new AdminTestDataImportLog
            {
                Level = level,
                Source = source,
                Message = message
            };

            LogQueue.Enqueue(new LogDbRecord
            {
                Id = log.Id,
                Timestamp = log.Timestamp,
                Type = log.Type,
                Source = log.Source,
                Level = log.Level,
                Message = log.Message
            });
        }
    }
}