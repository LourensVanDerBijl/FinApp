namespace FinBineBackend.AdminGroupView.Logs.Models
{
    public class AdminGroupViewLog
    {
        public Guid Id { get; set; } = Guid.NewGuid();

        public DateTime Timestamp { get; set; } = DateTime.UtcNow;

        public string Type { get; set; } = "AdminGroupView";

        public string Source { get; set; } = "Firestore";

        public string Level { get; set; } = string.Empty;

        public string Message { get; set; } = string.Empty;
    }
}
