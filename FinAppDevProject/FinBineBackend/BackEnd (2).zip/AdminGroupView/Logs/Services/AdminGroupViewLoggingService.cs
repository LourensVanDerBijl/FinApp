using FinBineBackend.AdminGroupView.Logs.Models;
using FinBineBackend.LoggingLogic.LogDbWrite.Models;
using FinBineBackend.LoggingLogic.LogDbWrite.Services;

namespace FinBineBackend.AdminGroupView.Logs.Services
{
    // Quiet by design, same convention as AdminDatabaseViewLoggingService
    // — this is a read-only page, so a clean list produces zero log
    // entries. Only auth failures and unexpected errors are worth a
    // record; there is no success/Info path here on purpose.
    public class AdminGroupViewLoggingService
    {
        public void LogUnauthorizedAccess(string ipAddress) =>
            CreateLog("Warning", "Auth", $"Non-admin or invalid token tried to reach the Groups page (IP: {ipAddress})");

        public void LogSystemError(string reason) =>
            CreateLog("Error", "AdminGroupView", $"Failed to build the group list: {reason}");

        private void CreateLog(string level, string source, string message)
        {
            var log = new AdminGroupViewLog
            {
                Level = level,
                Source = source,
                Message = message
            };

            LogQueue.Enqueue(new LogDbRecord
            {
                Id = log.Id,
                Timestamp = log.Timestamp,
                Type = log.Type,
                Source = log.Source,
                Level = log.Level,
                Message = log.Message
            });
        }
    }
}
