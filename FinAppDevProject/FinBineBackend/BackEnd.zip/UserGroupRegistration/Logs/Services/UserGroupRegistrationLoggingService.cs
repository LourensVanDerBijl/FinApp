﻿using FinBineBackend.UserGroupRegistration.Logs.Models;
using FinBineBackend.LoggingLogic.LogDbWrite.Models;
using FinBineBackend.LoggingLogic.LogDbWrite.Services;

namespace FinBineBackend.UserGroupRegistration.Logs.Services
{
    // Deliberately quiet by design, same convention as
    // UserRegistrationLoggingService/UserLoginLoggingService — a clean
    // group creation produces zero log entries. Only validation
    // rejections, rollbacks, and token problems are logged.
    public class UserGroupRegistrationLoggingService
    {
        // The token is structurally invalid — not just expired or
        // revoked, but doesn't check out at all. Worth treating as a
        // possible theft attempt, same as UserLoginLoggingService.
        public void LogTokenMismatch(string ipAddress) =>
            CreateLog("Critical", "Auth", $"Group creation token failed verification — possible account theft attempt (IP: {ipAddress})");

        // A request was rejected before anything was created — failed
        // validation (bad group name/type), no matching fb_users
        // profile, or the owner already belongs to a group.
        public void LogRegistrationRejected(string source, string userId, string reason) =>
            CreateLog("Warning", source, $"Group creation rejected for {userId}: {reason}");

        // The fb_groups document was created but assigning the owner
        // afterwards failed — this is what triggers rollback.
        public void LogRollbackTriggered(string userId, string? groupId, string reason) =>
            CreateLog("Error", "Firestore", $"Group creation failed for owner {userId} (groupId: {groupId ?? "not yet assigned"}) — rolling back. Reason: {reason}");

        // Worst case: undoing the already-created group document also
        // failed, leaving an orphaned fb_groups record that needs
        // manual cleanup.
        public void LogRollbackFailed(string userId, string groupId, string reason) =>
            CreateLog("Critical", "Firestore", $"ROLLBACK FAILED for groupId={groupId}, owner={userId} — manual cleanup required. Reason: {reason}");

        private void CreateLog(string level, string source, string message)
        {
            var log = new UserGroupRegistrationLog
            {
                Level = level,
                Source = source,
                Message = message
            };

            LogQueue.Enqueue(new LogDbRecord
            {
                Id = log.Id,
                Timestamp = log.Timestamp,
                Type = log.Type,
                Source = log.Source,
                Level = log.Level,
                Message = log.Message
            });
        }
    }
}
