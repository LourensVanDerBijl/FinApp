﻿namespace FinBineBackend.UserGroupRegistration.Logs.Models
{
    public class UserGroupRegistrationLog
    {
        public Guid Id { get; set; } = Guid.NewGuid();
        public DateTime Timestamp { get; set; } = DateTime.UtcNow;
        public string Type { get; set; } = "Group Reg";
        public string Source { get; set; } = string.Empty;
        public string Level { get; set; } = string.Empty;
        public string Message { get; set; } = string.Empty;
    }
}
