﻿namespace FinBineBackend.BackEnd.Logs.Models
{
    public class BackEndLog
    {
        public Guid Id { get; set; } = Guid.NewGuid();

        public DateTime Timestamp { get; set; } = DateTime.UtcNow;

        public string Type { get; set; } = "Backend";

        public string Source { get; set; } = "C#";

        public string Level { get; set; } = string.Empty;

        public string Message { get; set; } = string.Empty;
    }
}