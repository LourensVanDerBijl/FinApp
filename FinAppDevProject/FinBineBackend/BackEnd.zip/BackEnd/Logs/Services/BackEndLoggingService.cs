﻿using FinBineBackend.BackEnd.Logs.Models;
using FinBineBackend.LoggingLogic.LogDbWrite.Models;
using FinBineBackend.LoggingLogic.LogDbWrite.Services;

namespace FinBineBackend.BackEnd.Logs.Services
{
    public class BackEndLoggingService
    {
        // --- General purpose logging ---
        public BackEndLog CreateInfoLog(string source, string message) => CreateLog("Info", source, message);
        public BackEndLog CreateSuccessLog(string source, string message) => CreateLog("Success", source, message);
        public BackEndLog CreateWarningLog(string source, string message) => CreateLog("Warning", source, message);
        public BackEndLog CreateErrorLog(string source, string message) => CreateLog("Error", source, message);

        // --- Backend lifecycle events ---
        public void LogBackendStarted() => CreateInfoLog("Backend", "Backend started");
        public void LogBackendStartedSuccessfully() => CreateSuccessLog("Backend", "Backend started successfully");
        public void LogBackendStartupFailed(Exception ex) => CreateErrorLog("Backend", $"Backend startup failed: {ex.Message}");
        public void LogBackendStopping() => CreateInfoLog("Backend", "Backend stopping");
        public void LogBackendStopped() => CreateSuccessLog("Backend", "Backend stopped");
        public void LogBackendShutdownFailed(Exception ex) => CreateErrorLog("Backend", $"Backend shutdown failed: {ex.Message}");

        // --- HTTP/API requests ---
        public void LogRequestReceived(string endpoint, string correlationId) =>
            CreateInfoLog("HTTP", $"Request received at {endpoint}, CorrelationId={correlationId}");

        public void LogRequestCompleted(string endpoint, string correlationId) =>
            CreateSuccessLog("HTTP", $"Request completed successfully at {endpoint}, CorrelationId={correlationId}");

        public void LogRequestFailed(string endpoint, string correlationId, Exception ex) =>
            CreateErrorLog("HTTP", $"Request failed at {endpoint}, CorrelationId={correlationId}, Exception={ex.Message}");

        public void LogRequestRejected(string endpoint, string correlationId, string reason) =>
            CreateWarningLog("HTTP", $"Request rejected at {endpoint}, CorrelationId={correlationId}, Reason={reason}");

        // --- Background jobs ---
        public void LogJobStarted(string jobName) =>
            CreateInfoLog("Job", $"Job started: {jobName}");

        public void LogJobCompleted(string jobName, int recordsProcessed, int recordsFailed, TimeSpan duration) =>
            CreateSuccessLog("Job", $"Job completed: {jobName}, Duration={duration}, RecordsProcessed={recordsProcessed}, RecordsFailed={recordsFailed}");

        public void LogJobFailed(string jobName, Exception ex) =>
            CreateErrorLog("Job", $"Job failed: {jobName}, Exception={ex.Message}");

        public void LogJobCancelled(string jobName) =>
            CreateWarningLog("Job", $"Job cancelled: {jobName}");

        public void LogJobTimedOut(string jobName, TimeSpan duration) =>
            CreateErrorLog("Job", $"Job timed out: {jobName}, Duration={duration}");

        // --- Configuration issues ---
        public void LogMissingConfiguration(string configName) =>
            CreateErrorLog("Configuration", $"Required configuration missing: {configName}");

        public void LogInvalidConfiguration(string configName) =>
            CreateErrorLog("Configuration", $"Invalid configuration: {configName}");

        public void LogMissingEnvironmentVariable(string variableName) =>
            CreateErrorLog("Configuration", $"Environment variable missing: {variableName}");

        public void LogExternalServiceConfigurationInvalid(string serviceName) =>
            CreateErrorLog("Configuration", $"External service configuration invalid: {serviceName}");

        public void LogCertificateFailure(string certName, Exception ex) =>
            CreateErrorLog("Configuration", $"Certificate/configuration failure: {certName}, Exception={ex.Message}");

        // --- Exception logging ---
        public void LogUnhandledException(Exception ex) =>
            CreateErrorLog("Exception", $"Unhandled exception: {ex}");

        public void LogServiceException(string serviceName, Exception ex) =>
            CreateErrorLog("Exception", $"Service exception in {serviceName}: {ex}");

        public void LogBackgroundTaskException(string taskName, Exception ex) =>
            CreateErrorLog("Exception", $"Background task exception in {taskName}: {ex}");

        // --- Core helper ---
        private BackEndLog CreateLog(string level, string source, string message)
        {
            var log = new BackEndLog
            {
                Level = level,
                Source = source,
                Message = message
            };

            LogQueue.Enqueue(new LogDbRecord
            {
                Id = log.Id,
                Timestamp = log.Timestamp,
                Type = log.Type,
                Source = log.Source,
                Level = log.Level,
                Message = log.Message
            });

            return log;
        }
    }
}