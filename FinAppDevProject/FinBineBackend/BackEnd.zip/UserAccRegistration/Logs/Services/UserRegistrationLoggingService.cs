﻿using FinBineBackend.UserAccRegistration.Logs.Models;
using FinBineBackend.LoggingLogic.LogDbWrite.Models;
using FinBineBackend.LoggingLogic.LogDbWrite.Services;

namespace FinBineBackend.UserAccRegistration.Logs.Services
{
    // Deliberately does NOT log every successful registration — only
    // problems. A clean registration produces zero log entries; that is
    // intentional, not an oversight.
    public class UserRegistrationLoggingService
    {
        // A registration was rejected before anything was created —
        // failed our own validation, or Firebase itself refused it
        // (e.g. email already in use, invalid token).
        public void LogRegistrationRejected(string source, string email, string reason) =>
            CreateLog("Warning", source, $"Registration rejected for {email}: {reason}");

        // A step failed AFTER something else had already succeeded —
        // this is what triggers the all-or-nothing rollback.
        public void LogRollbackTriggered(string source, string email, string? userId, string reason) =>
            CreateLog("Error", source,
                $"Registration failed for {email} (userId: {userId ?? "not yet assigned"}) — rolling back. Reason: {reason}");

        // Worst case: undoing an already-completed step also failed,
        // leaving an orphaned record that needs manual cleanup.
        public void LogRollbackFailed(string source, string? userId, string? firebaseUid, string reason) =>
            CreateLog("Critical", source,
                $"ROLLBACK FAILED for userId={userId ?? "unknown"}, firebaseUid={firebaseUid ?? "unknown"} — manual cleanup required. Reason: {reason}");

        private void CreateLog(string level, string source, string message)
        {
            var log = new UserRegistrationLog
            {
                Level = level,
                Source = source,
                Message = message
            };

            LogQueue.Enqueue(new LogDbRecord
            {
                Id = log.Id,
                Timestamp = log.Timestamp,
                Type = log.Type,
                Source = log.Source,
                Level = log.Level,
                Message = log.Message
            });
        }
    }
}