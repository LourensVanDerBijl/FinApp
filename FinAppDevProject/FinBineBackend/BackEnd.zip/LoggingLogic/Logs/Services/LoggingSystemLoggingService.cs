﻿using FinBineBackend.LoggingLogic.Logs.Models;
using FinBineBackend.LoggingLogic.LogDbWrite.Models;
using FinBineBackend.LoggingLogic.LogDbWrite.Services;

namespace FinBineBackend.LoggingLogic.Logs.Services
{
    public class LoggingSystemLoggingService
    {
        public void LogDatabaseSaveFailed(Exception ex) =>
            CreateLog("Error", "PostgreSQL", $"Failed to save logs to the database: {ex.Message}");

        public void LogApiRequestFailed(Exception ex) =>
            CreateLog("Error", "API", $"Logs API request failed: {ex.Message}");

        private void CreateLog(string level, string source, string message)
        {
            var log = new LoggingSystemLog
            {
                Level = level,
                Source = source,
                Message = message
            };

            LogQueue.Enqueue(new LogDbRecord
            {
                Id = log.Id,
                Timestamp = log.Timestamp,
                Type = log.Type,
                Source = log.Source,
                Level = log.Level,
                Message = log.Message
            });
        }
    }
}