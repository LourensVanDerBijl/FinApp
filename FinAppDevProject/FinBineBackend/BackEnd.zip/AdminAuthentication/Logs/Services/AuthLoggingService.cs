﻿using FinBineBackend.AdminAuthentication.Logs.Models;
using FinBineBackend.LoggingLogic.LogDbWrite.Models;
using FinBineBackend.LoggingLogic.LogDbWrite.Services;

namespace FinBineBackend.AdminAuthentication.Logs.Services
{
    public class AuthLoggingService
    {
        // --- Successful login ---
        public void LogAdminLoginSuccess(string preferName, string surname, string accountType) =>
            CreateLog("Success", $"{preferName} {surname} ({accountType}) successfully authenticated");

        // --- Valid Firebase login, but not a registered admin ---
        public void LogAdminNotRegistered(string ipAddress) =>
            CreateLog("Warning", $"Login rejected — account not registered as admin (IP: {ipAddress})");

        // --- Token problems ---
        public void LogTokenExpired(string ipAddress) =>
            CreateLog("Warning", $"Login rejected — token expired (IP: {ipAddress})");

        public void LogTokenRevoked(string ipAddress) =>
            CreateLog("Warning", $"Login rejected — token revoked (IP: {ipAddress})");

        public void LogTokenInvalid(string ipAddress) =>
            CreateLog("Critical", $"Login rejected — invalid or forged token (IP: {ipAddress})");

        public void LogAuthErrorOther(string errorCode, string ipAddress) =>
            CreateLog("Warning", $"Login rejected — authentication error: {errorCode} (IP: {ipAddress})");

        // --- System-level failure (not the user's fault) ---
        public void LogSystemError(string exceptionMessage) =>
            CreateLog("Error", $"Login check failed due to a system error: {exceptionMessage}");

        // --- Core helper ---
        private void CreateLog(string level, string message)
        {
            var log = new AuthLog
            {
                Level = level,
                Message = message
            };

            LogQueue.Enqueue(new LogDbRecord
            {
                Id = log.Id,
                Timestamp = log.Timestamp,
                Type = log.Type,
                Source = log.Source,
                Level = log.Level,
                Message = log.Message
            });
        }
    }
}