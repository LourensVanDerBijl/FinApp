﻿namespace FinBineBackend.AdminAuthentication.Logs.Models
{
    public class AuthLog
    {
        public Guid Id { get; set; } = Guid.NewGuid();

        public DateTime Timestamp { get; set; } = DateTime.UtcNow;

        public string Type { get; set; } = "Auth";

        public string Source { get; set; } = "Firebase";

        public string Level { get; set; } = string.Empty;

        public string Message { get; set; } = string.Empty;
    }
}