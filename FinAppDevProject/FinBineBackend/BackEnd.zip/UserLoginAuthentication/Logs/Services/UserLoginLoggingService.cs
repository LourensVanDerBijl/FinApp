﻿using FinBineBackend.UserLoginAuthentication.Logs.Models;
using FinBineBackend.LoggingLogic.LogDbWrite.Models;
using FinBineBackend.LoggingLogic.LogDbWrite.Services;

namespace FinBineBackend.UserLoginAuthentication.Logs.Services
{
    // Deliberately quiet by design. A normal login, and a normal expired
    // or revoked session, are NOT logged here at all — only things that
    // look like a genuine security or data problem are.
    public class UserLoginLoggingService
    {
        // The token is structurally invalid — not just expired or
        // revoked, but doesn't check out at all. Worth treating as a
        // possible account theft attempt.
        public void LogTokenMismatch(string ipAddress) =>
            CreateLog("Critical", $"Login token failed verification — possible account theft attempt (IP: {ipAddress})");

        // A valid Firebase login with no matching fb_users profile. This
        // should never happen if registration is working correctly — it
        // may mean a user's profile was lost or corrupted, so this is
        // Critical, not routine.
        public void LogAccountNotFound(string ipAddress) =>
            CreateLog("Critical", $"Valid login token, but no matching fb_users profile found — possible lost user profile (IP: {ipAddress})");

        public void LogAccountNotActive(string userId, string memberStatus, string ipAddress) =>
            CreateLog("Warning", $"Login blocked — account {userId} is {memberStatus} (IP: {ipAddress})");

        public void LogLastActivityUpdateFailed(string userId, string reason) =>
            CreateLog("Error", $"Failed to update last_activity for {userId}: {reason}");

        private void CreateLog(string level, string message)
        {
            var log = new UserLoginLog
            {
                Level = level,
                Message = message
            };

            LogQueue.Enqueue(new LogDbRecord
            {
                Id = log.Id,
                Timestamp = log.Timestamp,
                Type = log.Type,
                Source = log.Source,
                Level = log.Level,
                Message = log.Message
            });
        }
    }
}