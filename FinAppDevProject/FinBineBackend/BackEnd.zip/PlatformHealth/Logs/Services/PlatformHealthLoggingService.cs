﻿using FinBineBackend.PlatformHealth.Logs.Models;
using FinBineBackend.LoggingLogic.LogDbWrite.Models;
using FinBineBackend.LoggingLogic.LogDbWrite.Services;

namespace FinBineBackend.PlatformHealth.Logs.Services
{
    public class PlatformHealthLoggingService
    {
        // --- Status actually changed ---
        public void LogServiceRecovered(string source) =>
            CreateLog("Success", source, $"{source} is back online");

        public void LogServiceDegraded(string source, int latencyMs) =>
            CreateLog("Warning", source, $"{source} response time degraded ({latencyMs}ms)");

        public void LogServiceDown(string source) =>
            CreateLog("Error", source, $"{source} is unreachable");

        public void LogInitialStatus(string source, string status) =>
            CreateLog("Info", source, $"Initial health check: {source} is {status}");

        // --- Periodic snapshot, every 30 minutes, regardless of change ---
        public void LogHeartbeat(string source, int latencyMs) =>
            CreateLog("Info", source, $"{source} heartbeat: {latencyMs}ms");

        // --- Our own health-check code broke, not the service itself ---
        public void LogHealthCheckException(string source, Exception ex) =>
            CreateLog("Error", source, $"Health check failed unexpectedly: {ex.Message}");

        private void CreateLog(string level, string source, string message)
        {
            var log = new PlatformHealthLog
            {
                Level = level,
                Source = source,
                Message = message
            };

            LogQueue.Enqueue(new LogDbRecord
            {
                Id = log.Id,
                Timestamp = log.Timestamp,
                Type = log.Type,
                Source = log.Source,
                Level = log.Level,
                Message = log.Message
            });
        }
    }
}